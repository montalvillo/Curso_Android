package com.example.juangarciamontalvillo.clase_09_tarea;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SegundaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);


        String x = getIntent().getStringExtra("edad");

        TextView label = (TextView)findViewById(R.id.secondlabel);

        label.setText(x);



    }
}
